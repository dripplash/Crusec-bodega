/**
 * Crusec Bodega
 * Sistema desarrollado por David Navarro por iniciativa propia
 * para apoyo interno de bodega Crusec Life Store.
 *
 * Nota de autoría:
 * Este desarrollo, su estructura técnica y futuras mejoras quedan sujetos a acuerdo
 * con David Navarro en caso de continuidad, modificación mayor, traspaso o uso
 * fuera de la operación interna de bodega.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');
const crypto = require('crypto');

function loadEnvFile() {
  const envPath = path.join(__dirname, '.env');
  if (!fs.existsSync(envPath)) return;

  for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const value = line.trim();
    if (!value || value.startsWith('#')) continue;

    const i = value.indexOf('=');
    if (i < 1) continue;

    const key = value.slice(0, i).trim();
    let val = value.slice(i + 1).trim();

    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }

    if (process.env[key] === undefined) process.env[key] = val;
  }
}

loadEnvFile();

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';

const PUBLIC_DIR = path.join(__dirname, 'public');
const PROJECT_DATA_DIR = path.join(__dirname, 'data');
const DATA_DIR = path.resolve(process.env.DATA_DIR || PROJECT_DATA_DIR);

const LOCATIONS_FILE = path.join(DATA_DIR, 'locations.json');
const SPECIAL_LOCATIONS_FILE = path.join(DATA_DIR, 'special-locations.json');
const PRODUCT_CACHE_FILE = path.join(DATA_DIR, 'products-cache.json');
const OAUTH_STATE_FILE = path.join(DATA_DIR, 'relbase-oauth-state.json');

const SEED_FILE = path.join(PROJECT_DATA_DIR, 'locations.seed.json');
const DEMO_PRODUCTS_FILE = path.join(PROJECT_DATA_DIR, 'demo-products.json');

const CATALOG_MODE = String(process.env.CATALOG_MODE || 'demo').toLowerCase();
const SYNC_INTERVAL_MINUTES = Math.max(1, Number(process.env.SYNC_INTERVAL_MINUTES || 10));

function normalizeSku(v) {
  return String(v || '').trim().toUpperCase();
}

function brandFromCode(code) {
  const sku = normalizeSku(code);
  const p = sku.charAt(0);

  if (p === 'P') return 'Pitaya';
  if (p === 'Y') return 'Yozen';

  return 'Crusec';
}
function ensureDataDir() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function ensureLocationFile() {
  ensureDataDir();

  if (!fs.existsSync(LOCATIONS_FILE)) {
    const seed = fs.existsSync(SEED_FILE)
      ? fs.readFileSync(SEED_FILE, 'utf8')
      : '{"locations":{}}';

    fs.writeFileSync(LOCATIONS_FILE, seed);
  }
}

function readLocations() {
  ensureLocationFile();

  try {
    const parsed = JSON.parse(fs.readFileSync(LOCATIONS_FILE, 'utf8'));

    return {
      locations: parsed.locations && typeof parsed.locations === 'object'
        ? parsed.locations
        : {},
    };
  } catch (error) {
    console.error('Error leyendo ubicaciones:', error);
    return { locations: {} };
  }
}

function writeLocations(db) {
  ensureLocationFile();

  const tmp = `${LOCATIONS_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, LOCATIONS_FILE);
}

function ensureSpecialLocationsFile() {
  ensureDataDir();
  if (!fs.existsSync(SPECIAL_LOCATIONS_FILE)) {
    fs.writeFileSync(SPECIAL_LOCATIONS_FILE, JSON.stringify({ locations: {} }, null, 2));
  }
}

function readSpecialLocations() {
  ensureSpecialLocationsFile();
  try {
    const parsed = JSON.parse(fs.readFileSync(SPECIAL_LOCATIONS_FILE, 'utf8'));
    return {
      locations: parsed.locations && typeof parsed.locations === 'object' ? parsed.locations : {},
    };
  } catch (error) {
    console.error('Error leyendo ubicaciones especiales:', error);
    return { locations: {} };
  }
}

function writeSpecialLocations(db) {
  ensureSpecialLocationsFile();
  const tmp = `${SPECIAL_LOCATIONS_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, SPECIAL_LOCATIONS_FILE);
}

const SPECIAL_AREAS = {
  pieza1: { label: 'Pieza 1', spots: { estante1: 'Estante 1', estante2: 'Estante 2', estante3: 'Estante 3' } },
  pieza2: { label: 'Pieza 2', spots: { estante1: 'Estante 1', estante2: 'Estante 2', estante3: 'Estante 3' } },
  pieza3: { label: 'Pieza 3', spots: { estante1: 'Estante 1', estante2: 'Estante 2', estante3: 'Estante 3' } },
  segundoPiso: { label: 'Segundo piso', spots: { pieza: 'Pieza', estante1: 'Estante 1' } },
};

function validateSpecialLocation(input) {
  const area = String(input.area || '').trim();
  const spot = String(input.spot || '').trim();
  const areaConfig = SPECIAL_AREAS[area];

  if (!areaConfig) return 'Selecciona una ubicación especial válida.';
  if (!areaConfig.spots[spot]) return 'Selecciona una zona válida dentro de la ubicación especial.';

  return {
    area,
    areaLabel: areaConfig.label,
    spot,
    spotLabel: areaConfig.spots[spot],
    fullLabel: `${areaConfig.label} — ${areaConfig.spots[spot]}`,
  };
}

function readDemoProducts() {
  const parsed = JSON.parse(fs.readFileSync(DEMO_PRODUCTS_FILE, 'utf8'));
  return Array.isArray(parsed.products) ? parsed.products : [];
}

function readProductCache() {
  ensureDataDir();

  try {
    if (!fs.existsSync(PRODUCT_CACHE_FILE)) {
      return {
        products: [],
        lastSyncAt: null,
        count: 0,
      };
    }

    const parsed = JSON.parse(fs.readFileSync(PRODUCT_CACHE_FILE, 'utf8'));
    const products = Array.isArray(parsed.products) ? parsed.products : [];

    return {
      products,
      lastSyncAt: parsed.lastSyncAt || null,
      count: Number(parsed.count || products.length || 0),
    };
  } catch (error) {
    console.error('Error leyendo caché de productos:', error);

    return {
      products: [],
      lastSyncAt: null,
      count: 0,
      error: error.message,
    };
  }
}

function writeProductCache(products) {
  ensureDataDir();

  const payload = {
    lastSyncAt: new Date().toISOString(),
    count: products.length,
    products,
  };

  const tmp = `${PRODUCT_CACHE_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(payload, null, 2));
  fs.renameSync(tmp, PRODUCT_CACHE_FILE);

  return payload;
}

async function syncRelbaseProducts() {
  const relbase = require('./src/relbase');
  const products = await relbase.listProducts();

  return writeProductCache(products);
}

async function getCatalog(options = {}) {
  const allowLiveFetch = Boolean(options.allowLiveFetch);

  if (CATALOG_MODE === 'relbase') {
    const cache = readProductCache();

    if (cache.products.length) {
      return cache.products;
    }

    if (allowLiveFetch) {
      const synced = await syncRelbaseProducts();
      return synced.products;
    }

    return [];
  }

  return readDemoProducts();
}

function mergeLocation(product, locationsDb) {
  const saved = locationsDb.locations[normalizeSku(product.sku)] || {};

  return {
    ...product,
    sku: normalizeSku(product.sku),
    brand: product.brand || brandFromCode(product.sku),
    location: saved.location || null,
    locationUpdatedAt: saved.locationUpdatedAt || null,
    locationUpdatedBy: saved.locationUpdatedBy || null,
  };
}

function publicProduct(product) {
  return {
    relbaseId: product.relbaseId || product.sku,
    sku: normalizeSku(product.sku),
    name: product.name || 'Producto sin nombre',
    barcode: product.barcode || '',
    brand: product.brand || brandFromCode(product.sku),
    active: product.active !== false,
    stock: product.stock ?? null,
    stockUpdatedAt: product.stockUpdatedAt || null,
    location: product.location || null,
    locationUpdatedAt: product.locationUpdatedAt || null,
    locationUpdatedBy: product.locationUpdatedBy || null,
  };
}

function validateLocation(input) {
  const aisle = Number(input.aisle);
  const side = String(input.side || '').trim().toUpperCase();
  const rack = Number(input.rack);
  const level = Number(input.level);

  const maxAisle = Number(process.env.MAX_AISLE || 6);
  const maxRack = Number(process.env.MAX_RACK || 11);
  const maxLevel = Number(process.env.MAX_LEVEL || 6);

  if (!Number.isInteger(aisle) || aisle < 1 || aisle > maxAisle) {
    return `El pasillo debe estar entre 1 y ${maxAisle}.`;
  }

  if (!['D', 'I'].includes(side)) {
    return 'El lado debe ser D (derecho) o I (izquierdo).';
  }

  if (!Number.isInteger(rack) || rack < 1 || rack > maxRack) {
    return `El rack debe estar entre 1 y ${maxRack}.`;
  }

  if (!Number.isInteger(level) || level < 1 || level > maxLevel) {
    return `El nivel debe estar entre 1 y ${maxLevel}.`;
  }

  const sideLabel = side === 'D' ? 'Derecho' : 'Izquierdo';

  return {
    aisle,
    side,
    sideLabel,
    rack,
    level,
    fullLabel: `Pasillo ${aisle} — lado ${sideLabel.toLowerCase()} — rack ${rack} — nivel ${level}`,
  };
}

function sendRedirect(res, location) {
  res.writeHead(302, { Location: location });
  res.end();
}

function htmlPage(title, message, extra = '') {
  return `<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>${title}</title>
  <style>
    body {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background: #f4f6f8;
      color: #111827;
      margin: 0;
      min-height: 100vh;
      display: grid;
      place-items: center;
    }
    main {
      width: min(680px, calc(100% - 32px));
      background: white;
      border: 1px solid #dbe2ea;
      border-radius: 20px;
      padding: 32px;
      box-shadow: 0 18px 50px rgba(15, 23, 42, 0.08);
    }
    h1 { margin-top: 0; }
    a {
      display: inline-block;
      margin-top: 16px;
      background: #1d4ed8;
      color: white;
      padding: 12px 16px;
      border-radius: 12px;
      text-decoration: none;
      font-weight: 800;
    }
    pre {
      background: #0f172a;
      color: #e5e7eb;
      padding: 14px;
      border-radius: 12px;
      overflow: auto;
    }
  </style>
</head>
<body>
  <main>
    <h1>${title}</h1>
    <p>${message}</p>
    ${extra}
    <a href="/">Volver a Crusec Bodega</a>
  </main>
</body>
</html>`;
}

function writeOAuthState(state) {
  ensureDataDir();

  fs.writeFileSync(OAUTH_STATE_FILE, JSON.stringify({
    state,
    createdAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + 10 * 60 * 1000).toISOString(),
  }, null, 2));
}

function readOAuthState() {
  try {
    if (!fs.existsSync(OAUTH_STATE_FILE)) return null;
    return JSON.parse(fs.readFileSync(OAUTH_STATE_FILE, 'utf8'));
  } catch {
    return null;
  }
}

function clearOAuthState() {
  try {
    if (fs.existsSync(OAUTH_STATE_FILE)) fs.unlinkSync(OAUTH_STATE_FILE);
  } catch {}
}

async function handleAuth(req, res, url) {
  const relbase = require('./src/relbase');

  if (req.method === 'GET' && url.pathname === '/auth/login') {
    const state = crypto.randomBytes(24).toString('hex');
    writeOAuthState(state);

    const loginUrl = relbase.getAuthUrl(state);
    return sendRedirect(res, loginUrl);
  }

  if (req.method === 'GET' && url.pathname === '/auth/callback') {
    const error = url.searchParams.get('error');
    const errorDescription = url.searchParams.get('error_description');

    if (error) {
      return sendText(
        res,
        400,
        htmlPage('Relbase no autorizó la conexión', `${errorDescription || error}`),
        'text/html; charset=utf-8'
      );
    }

    const code = url.searchParams.get('code');
    const state = url.searchParams.get('state');
    const savedState = readOAuthState();

    if (!code) {
      return sendText(
        res,
        400,
        htmlPage('Falta el código de autorización', 'Relbase no devolvió el código necesario para conectar.'),
        'text/html; charset=utf-8'
      );
    }

    if (!savedState || savedState.state !== state || new Date(savedState.expiresAt).getTime() < Date.now()) {
      return sendText(
        res,
        400,
        htmlPage('Autorización inválida o expirada', 'Vuelve a iniciar sesión desde /auth/login.'),
        'text/html; charset=utf-8'
      );
    }

    try {
      const token = await relbase.exchangeCodeForToken(code);
      clearOAuthState();

      return sendText(
        res,
        200,
        htmlPage(
          'Relbase conectado correctamente',
          'La autorización fue guardada. Ahora la app puede leer productos desde Relbase.',
          `<pre>Token válido hasta: ${token.expires_at || 'sin fecha informada'}</pre>`
        ),
        'text/html; charset=utf-8'
      );
    } catch (authError) {
      console.error(authError);

      return sendText(
        res,
        500,
        htmlPage('No se pudo conectar Relbase', authError.message || 'Error desconocido.'),
        'text/html; charset=utf-8'
      );
    }
  }

  return sendJson(res, 404, { error: 'Ruta auth no encontrada.' });
}

function sendJson(res, code, payload) {
  const body = JSON.stringify(payload);

  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
  });

  res.end(body);
}

function sendText(res, code, text, type = 'text/plain; charset=utf-8') {
  res.writeHead(code, {
    'Content-Type': type,
    'Content-Length': Buffer.byteLength(text),
  });

  res.end(text);
}

async function readBody(req) {
  const chunks = [];

  for await (const chunk of req) chunks.push(chunk);

  if (!chunks.length) return {};

  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw new Error('La solicitud no contiene JSON válido.');
  }
}

async function productSnapshot() {
  const [catalog, locations] = await Promise.all([
    getCatalog(),
    Promise.resolve(readLocations()),
  ]);

  return catalog.map((p) => mergeLocation(p, locations));
}

function getSyncStatusText(cache, relbaseStatus) {
  if (CATALOG_MODE !== 'relbase') {
    return 'Modo demo: Relbase pendiente de conectar';
  }

  if (!relbaseStatus?.authorized) {
    return 'Relbase pendiente de autorización';
  }

  if (!cache.lastSyncAt || !cache.products.length) {
    return 'Relbase conectado · presiona Sincronizar para cargar productos';
  }

  return `Relbase conectado · ${cache.products.length} productos guardados`;
}

async function handleApi(req, res, url) {
  if (req.method === 'GET' && url.pathname === '/api/status') {
    let relbaseStatus = null;
    let productCount = 0;
    let cache = { products: [], lastSyncAt: null, count: 0 };

    try {
      if (CATALOG_MODE === 'relbase') {
        const relbase = require('./src/relbase');
        relbaseStatus = relbase.status();
        cache = readProductCache();
        productCount = cache.products.length;
      } else {
        const demo = readDemoProducts();
        productCount = demo.length;
      }
    } catch (error) {
      relbaseStatus = {
        configured: true,
        authorized: false,
        error: error.message,
      };
    }

    return sendJson(res, 200, {
      relbaseEnabled: CATALOG_MODE === 'relbase',
      relbaseAuthorized: Boolean(relbaseStatus?.authorized),
      relbaseStatus,
      mode: CATALOG_MODE,
      lastSyncAt: CATALOG_MODE === 'relbase' ? cache.lastSyncAt : null,
      syncStatus: getSyncStatusText(cache, relbaseStatus),
      productCount,
      syncIntervalMinutes: SYNC_INTERVAL_MINUTES,
      storage: DATA_DIR,
      cacheFile: CATALOG_MODE === 'relbase' ? PRODUCT_CACHE_FILE : null,
      specialLocationsFile: SPECIAL_LOCATIONS_FILE,
    });
  }

  if (req.method === 'GET' && url.pathname === '/api/products/search') {
    const sku = normalizeSku(url.searchParams.get('sku'));

    if (!sku) {
      return sendJson(res, 400, { error: 'Debes ingresar un SKU o código de barras.' });
    }

    const products = await productSnapshot();

    if (CATALOG_MODE === 'relbase' && !products.length) {
      return sendJson(res, 409, {
        error: 'Aún no hay productos sincronizados. Presiona "Sincronizar con Relbase" primero.',
      });
    }

    const product = products.find((p) =>
      normalizeSku(p.sku) === sku ||
      normalizeSku(p.barcode) === sku
    );

    if (!product) {
      return sendJson(res, 404, { error: 'Código de producto no registrado.' });
    }

    const cache = CATALOG_MODE === 'relbase' ? readProductCache() : { lastSyncAt: null };

    return sendJson(res, 200, {
      product: publicProduct(product),
      lastSyncAt: cache.lastSyncAt,
    });
  }

  if (req.method === 'GET' && url.pathname === '/api/products') {
    const filter = String(url.searchParams.get('filter') || 'all');
    const q = String(url.searchParams.get('q') || '').trim().toUpperCase();

    let products = await productSnapshot();
    const cache = CATALOG_MODE === 'relbase' ? readProductCache() : { lastSyncAt: null, products: [] };

    if (filter === 'unassigned') products = products.filter((p) => !p.location);
    if (filter === 'assigned') products = products.filter((p) => Boolean(p.location));
    if (filter === 'with-stock') products = products.filter((p) => Number(p.stock) > 0);
    if (filter === 'without-stock') products = products.filter((p) => Number(p.stock) === 0);

    if (q) {
      products = products.filter((p) =>
        normalizeSku(p.sku).includes(q) ||
        String(p.name || '').toUpperCase().includes(q) ||
        String(p.brand || '').toUpperCase().includes(q) ||
        normalizeSku(p.barcode).includes(q)
      );
    }

    products.sort((a, b) => {
      if (Boolean(a.location) !== Boolean(b.location)) {
        return a.location ? 1 : -1;
      }

      return normalizeSku(a.sku).localeCompare(normalizeSku(b.sku));
    });

    let relbaseStatus = null;

    if (CATALOG_MODE === 'relbase') {
      try {
        const relbase = require('./src/relbase');
        relbaseStatus = relbase.status();
      } catch {}
    }

    return sendJson(res, 200, {
      products: products.map(publicProduct),
      lastSyncAt: CATALOG_MODE === 'relbase' ? cache.lastSyncAt : null,
      syncStatus: getSyncStatusText(cache, relbaseStatus),
    });
  }

  const match = url.pathname.match(/^\/api\/products\/([^/]+)\/location$/);

  if (match && req.method === 'PUT') {
    const sku = normalizeSku(decodeURIComponent(match[1]));
    const products = await getCatalog();

    const exists = products.some((p) => normalizeSku(p.sku) === sku);

    if (!exists) {
      return sendJson(res, 404, { error: 'Producto no encontrado.' });
    }

    const body = await readBody(req);
    const location = validateLocation(body);

    if (typeof location === 'string') {
      return sendJson(res, 400, { error: location });
    }

    const db = readLocations();

    db.locations[sku] = {
      location,
      locationUpdatedAt: new Date().toISOString(),
      locationUpdatedBy: String(body.updatedBy || 'Sin identificar').trim() || 'Sin identificar',
    };

    writeLocations(db);

    const product = mergeLocation(
      products.find((p) => normalizeSku(p.sku) === sku),
      db
    );

    return sendJson(res, 200, {
      product: publicProduct(product),
      message: 'Ubicación guardada correctamente.',
    });
  }

  if (match && req.method === 'DELETE') {
    const sku = normalizeSku(decodeURIComponent(match[1]));
    const products = await getCatalog();
    const base = products.find((p) => normalizeSku(p.sku) === sku);

    if (!base) {
      return sendJson(res, 404, { error: 'Producto no encontrado.' });
    }

    const db = readLocations();
    delete db.locations[sku];
    writeLocations(db);

    return sendJson(res, 200, {
      product: publicProduct(mergeLocation(base, db)),
      message: 'Ubicación eliminada.',
    });
  }

  if (req.method === 'GET' && url.pathname === '/api/special-locations/options') {
    return sendJson(res, 200, { areas: SPECIAL_AREAS });
  }

  if (req.method === 'GET' && url.pathname === '/api/special-locations') {
    const area = String(url.searchParams.get('area') || '').trim();
    const spot = String(url.searchParams.get('spot') || '').trim();
    const q = String(url.searchParams.get('q') || '').trim().toUpperCase();
    const db = readSpecialLocations();
    const catalog = await getCatalog();
    const bySku = new Map(catalog.map((p) => [normalizeSku(p.sku), p]));

    let items = Object.entries(db.locations).map(([sku, saved]) => {
      const base = bySku.get(normalizeSku(sku));
      return {
        sku: normalizeSku(sku),
        name: base?.name || 'Producto no disponible en catálogo',
        brand: base?.brand || brandFromCode(sku),
        stock: base?.stock ?? null,
        specialLocation: saved.specialLocation || null,
        specialLocationUpdatedAt: saved.specialLocationUpdatedAt || null,
        specialLocationUpdatedBy: saved.specialLocationUpdatedBy || null,
      };
    });

    if (area) items = items.filter((item) => item.specialLocation?.area === area);
    if (spot) items = items.filter((item) => item.specialLocation?.spot === spot);
    if (q) {
      items = items.filter((item) =>
        item.sku.includes(q) ||
        String(item.name || '').toUpperCase().includes(q) ||
        String(item.brand || '').toUpperCase().includes(q)
      );
    }

    items.sort((a, b) => a.sku.localeCompare(b.sku));
    return sendJson(res, 200, { items });
  }

  const specialMatch = url.pathname.match(/^\/api\/products\/([^/]+)\/special-location$/);

  if (specialMatch && req.method === 'PUT') {
    const sku = normalizeSku(decodeURIComponent(specialMatch[1]));
    const products = await getCatalog();
    const base = products.find((p) => normalizeSku(p.sku) === sku);
    if (!base) return sendJson(res, 404, { error: 'Producto no encontrado.' });

    const body = await readBody(req);
    const specialLocation = validateSpecialLocation(body);
    if (typeof specialLocation === 'string') return sendJson(res, 400, { error: specialLocation });

    const db = readSpecialLocations();
    db.locations[sku] = {
      specialLocation,
      specialLocationUpdatedAt: new Date().toISOString(),
      specialLocationUpdatedBy: String(body.updatedBy || 'Sin identificar').trim() || 'Sin identificar',
    };
    writeSpecialLocations(db);

    return sendJson(res, 200, {
      item: {
        sku,
        name: base.name || 'Producto sin nombre',
        brand: base.brand || brandFromCode(sku),
        stock: base.stock ?? null,
        ...db.locations[sku],
      },
      message: 'Ubicación especial guardada correctamente.',
    });
  }

  if (specialMatch && req.method === 'DELETE') {
    const sku = normalizeSku(decodeURIComponent(specialMatch[1]));
    const db = readSpecialLocations();
    delete db.locations[sku];
    writeSpecialLocations(db);
    return sendJson(res, 200, { message: 'Ubicación especial eliminada.' });
  }

  if (req.method === 'POST' && url.pathname === '/api/sync') {
    if (CATALOG_MODE !== 'relbase') {
      return sendJson(res, 409, {
        error: 'Relbase todavía no está conectado. La app está funcionando con productos de demostración.',
      });
    }

    try {
      const synced = await syncRelbaseProducts();

      return sendJson(res, 200, {
        message: `Sincronización completada. ${synced.products.length} productos guardados.`,
        productCount: synced.products.length,
        lastSyncAt: synced.lastSyncAt,
      });
    } catch (error) {
      console.error('Error sincronizando Relbase:', error);

      const cache = readProductCache();

      return sendJson(res, 502, {
        error: `${error.message || 'No se pudo sincronizar Relbase.'}${cache.products.length ? ` Se mantiene el caché anterior con ${cache.products.length} productos.` : ''}`,
        productCount: cache.products.length,
        lastSyncAt: cache.lastSyncAt,
      });
    }
  }

  return sendJson(res, 404, { error: 'Ruta no encontrada.' });
}

function serveStatic(res, pathname) {
  const rel = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
  const file = path.normalize(path.join(PUBLIC_DIR, rel));

  if (!file.startsWith(PUBLIC_DIR)) {
    return sendText(res, 403, 'Acceso denegado');
  }

  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    return sendText(res, 404, 'Archivo no encontrado');
  }

  const ext = path.extname(file).toLowerCase();

  const types = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.png': 'image/png',
    '.ico': 'image/x-icon',
    '.json': 'application/json; charset=utf-8',
  };

  const content = fs.readFileSync(file);

  res.writeHead(200, {
    'Content-Type': types[ext] || 'application/octet-stream',
    'Content-Length': content.length,
    'Cache-Control': ext === '.html' ? 'no-store' : 'public, max-age=300',
  });

  res.end(content);
}

ensureLocationFile();

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

    if (url.pathname.startsWith('/auth/')) {
      return await handleAuth(req, res, url);
    }

    if (url.pathname.startsWith('/api/')) {
      return await handleApi(req, res, url);
    }

    return serveStatic(res, url.pathname);
  } catch (error) {
    console.error(error);

    return sendJson(res, 500, {
      error: error.message || 'Error interno del servidor.',
    });
  }
});

server.listen(PORT, HOST, () => {
  console.log(`Crusec Bodega disponible en http://localhost:${PORT}`);
  console.log(`Catálogo: ${CATALOG_MODE}. Ubicaciones: ${LOCATIONS_FILE}`);
  console.log(`Caché productos: ${PRODUCT_CACHE_FILE}`);
});
